# -*- coding: utf-8 -*-
"""
Compressor Model,fslove function will be used to solve any paremeters with some 
specified arguments
Created on Thu Oct 04 21:52:45 2018

@author: whiff
"""
from __future__ import division, print_function
from CoolProp.CoolProp import PropsSI
import CoolProp as CP

class CompressorClass():
    def __init__(self,**kwargs):
        #Load up the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def update(self,**kwargs):
        #Update the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def calculate(self):
        #AbstractState
        if hasattr(self,'Backend'): #check if backend is given
            AS = CP.AbstractState(self.Backend, self.ref)
        else: #otherwise, use the defualt backend
            AS = CP.AbstractState('HEOS', self.ref)
        self.AS = AS
        
        #Local copies of coefficients
        P=self.P
        M=self.M
        
        #Calculate suction superheat and dew temperatures
        AS.update(CP.PQ_INPUTS, self.Pin_r, 1.0)
        self.Tsat_s_K=AS.T() #[K]
        
        AS.update(CP.PQ_INPUTS, self.Pout_r, 1.0)
        self.Tsat_d_K=AS.T() #[K]
        
        self.DT_sh_K=self.Tin_r-self.Tsat_s_K
        
        #Convert saturation temperatures in K to F
        Tsat_s = self.Tsat_s_K * 9/5 - 459.67
        Tsat_d = self.Tsat_d_K * 9/5 - 459.67
    
        #Apply the 10 coefficient ARI map to saturation temps in F
        power_map = P[0] + P[1] * Tsat_s + P[2] * Tsat_d + P[3] * Tsat_s**2 + P[4] * Tsat_s * Tsat_d + P[5] * Tsat_d**2 + P[6] * Tsat_s**3 + P[7] * Tsat_d * Tsat_s**2 + P[8] * Tsat_d**2*Tsat_s + P[9] * Tsat_d**3
        mdot_map = M[0] + M[1] * Tsat_s + M[2] * Tsat_d + M[3] * Tsat_s**2 + M[4] * Tsat_s * Tsat_d + M[5] * Tsat_d**2 + M[6] * Tsat_s**3 + M[7] * Tsat_d * Tsat_s**2 + M[8] * Tsat_d**2*Tsat_s + M[9] * Tsat_d**3
    
        # Convert mass flow rate to kg/s from lbm/h
        mdot_map *= 0.000125998 
    
        # Add more mass flow rate to scale
        mdot_map*=self.Vdot_ratio
        power_map*=self.Vdot_ratio
    
        P1 = self.Pin_r
        P2 = self.Pout_r
        T1_actual = self.Tsat_s_K + self.DT_sh_K
        T1_map = self.Tsat_s_K + 20 * 5 / 9
    
        AS.update(CP.PT_INPUTS, P1, T1_map)
        v_map = 1 / AS.rhomass() #[m^3/kg]
        s1_map = AS.smass() #[J/kg-K]
        h1_map = AS.hmass() #[J/kg]
        
        AS.update(CP.PT_INPUTS, P1, T1_actual)
        s1_actual = AS.smass() #[J/kg-K]
        h1_actual = AS.hmass() #[J/kg]
        v_actual = 1 / AS.rhomass() #[m^3/kg]
        F = 0.75
        mdot = (1 + F * (v_map / v_actual - 1)) * mdot_map
        
        AS.update(CP.PSmass_INPUTS, P2, s1_map)
        h2s_map = AS.hmass() #[J/kg]        
        
        AS.update(CP.PSmass_INPUTS, P2, s1_actual)
        h2s_actual = AS.hmass() #[J/kg]
    
        #Shaft power based on 20F superheat calculation from fit overall isentropic efficiency
        power = power_map * (mdot / mdot_map) * (h2s_actual - h1_actual) / (h2s_map - h1_map)
    
        h2 = power * (1 - self.fp) / mdot + h1_actual
        self.eta_oi=mdot*(h2s_actual-h1_actual)/(power)
        
        AS.update(CP.HmassP_INPUTS, h2, P2)
        self.Tout_r = AS.T() #[K]
        self.sout_r = AS.smass() #[J/kg-K]        
        
        self.sin_r = s1_actual
        self.hout_r = h2
        self.hin_r = h1_actual
        self.mdot_r=mdot
        self.W=power
        self.CycleEnergyIn=power*(1-self.fp)
        self.Vdot_pumped= mdot*v_actual
        self.Q_amb=-self.fp*power
        

if __name__=='__main__':
    kwds={
          'ref':'R134a',
          'Backend':'HEOS', #choose between: 'HEOS','TTSE&HEOS','BICUBIC&HEOS','REFPROP','SRK','PR'
          'Tin_r':10+273.15,
          'Pin_r':PropsSI('P','T',5+273.15,'Q',1,'R134a'),
          'Pout_r':PropsSI('P','T',45+273.15,'Q',1,'R134a'),
          'M':[217.3163128,5.094492028,-0.593170311,4.38E-02,-2.14E-02,1.04E-02,7.90E-05,-5.73E-05,1.79E-04,-8.08E-05],
          'P':[-561.3615705,-15.62601841,46.92506685,-0.217949552,0.435062616,-0.442400826,2.25E-04,2.37E-03,-3.32E-03,2.50E-03],
          'fp':0.15, #Fraction of electrical power lost as heat to ambient
          'Vdot_ratio': 1.0 #Displacement Scale factor
          }
    
    Comp=CompressorClass(**kwds)
    Comp.calculate()
    print('Power',Comp.W,'W')
    print('Volumetric Flow Rate',Comp.Vdot_pumped,'m^3/s')
    print('heat transfer',Comp.Q_amb, 'W')
    print ('mass flow',Comp.mdot_r,'Kg/s')


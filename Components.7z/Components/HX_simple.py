# -*- coding: utf-8 -*-
"""
Created on Sun Oct 14 09:21:53 2018

@author: whiff
"""

from __future__ import division
from CoolProp.CoolProp import PropsSI
import CoolProp as CP
from math import exp
class HXElementClass():
    def __init__(self,**kwargs):
        #Load up the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def update(self,**kwargs):
        #Update the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def output(self):
        pass

        
    def calculate(self):        
        #Abstract State
        AS_r = CP.AbstractState(self.Backend_r, self.ref)
        AS_r.update(CP.PT_INPUTS,self.Pin_r,self.Tin_r)
        self.hin_r=AS_r.hmass() ###

        U=10        
        self.Q=U*self.Area*(self.Tin_m-self.Tin_r)# positive if absorb heat
        self.hout_r=self.Q/self.mdot_r+self.hin_r
        
        #pressure drop calculation
        self.Pout_r=self.Pin_r #pressure drop should be added later
        
        #other values
        AS_r.update(CP.HmassP_INPUTS, self.hout_r, self.Pout_r)
        self.Tout_r = AS_r.T() #[K]
 
    

if __name__=='__main__':
    kwds={
            'ref':'R134a',
            'Backend_r':'HEOS',
            'medium':'Water',
            'Backend_m':'HEOS',
            # inlet state of mediums
            'Pin_r':1500000,
            'Tin_r':0+273.15,
            'mdot_r':0.1,
            'Pin_m':100000,
            'Tin_m':20+273.15,
            'mdot_m':1, 
            #geometry information
            'Area':12
 #air property is not know
          }
    hx=HXElementClass(**kwds)
    hx.calculate()
    print hx.Q
    print hx.Tout_r
    print hx.Area

'''        Cp_r_in=AS_r.cpmass()
        Cp_r=Cp_r_in
 
        AS_m.update(CP.PT_INPUTS,self.Pin_m,self.Tin_m)
        Cp_m_in=AS_m.cpmass()
        Cp_m=Cp_m_in
        
        #got parameters through calculation of fluid properties
        C=[Cp_r*self.mdot_r,Cp_m*self.mdot_m]
        Cmin=min(C)
        Cmax=max(C)
        Cr=Cmin/Cmax
'''      
 


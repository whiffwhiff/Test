# -*- coding: utf-8 -*-
"""
Created on Sun Oct 14 09:21:53 2018

@author: whiff
"""

from __future__ import division
from CoolProp.CoolProp import PropsSI
import CoolProp as CP
from math import exp
class HXElementClass():
    def __init__(self,**kwargs):
        #Load up the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def update(self,**kwargs):
        #Update the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def output(self):
        pass

        
    def calculate(self):        
        #Abstract State
        AS_r = CP.AbstractState(self.Backend_r, self.ref)
        AS_m = CP.AbstractState(self.Backend_m, self.medium)
        
        AS_r.update(CP.PT_INPUTS,self.Pin_r,self.Tin_r)
        self.hin_r=AS_r.hmass() ###
        Cp_r_in=AS_r.cpmass()
        Cp_r=Cp_r_in
 
        AS_m.update(CP.PT_INPUTS,self.Pin_m,self.Tin_m)
        Cp_m_in=AS_m.cpmass()
        Cp_m=Cp_m_in
        
        #got parameters through calculation of fluid properties
        C=[Cp_r*self.mdot_r,Cp_m*self.mdot_m]
        Cmin=min(C)
        Cmax=max(C)
        Cr=Cmin/Cmax
        
        #solve heat transfer coefficient
        U=self.UFun()
        print ('U',U)
        
        #solve heat transfer area
        self.Area=self.areaFun()
        
        #solve heat flow with NTU-e method
        Ntu=U*self.Area/Cmin
        '''epsilon=self.epsilonFun(Ntu,Cr)'''
        epsilon=5
        self.Q=epsilon*Cmin*(self.Tin_m-self.Tin_r)# positive if absorb heat
        self.hout_r=self.Q/self.mdot_r+self.hin_r
        
        #pressure drop calculation
        self.Pout_r=self.Pin_r #pressure drop should be added later
        
        #other values
        AS_r.update(CP.HmassP_INPUTS, self.hout_r, self.Pout_r)
        self.Tout_r = AS_r.T() #[K]
 

    def epsilonFun(self,Ntu,Cr):
        #first, judge which formula should be used, currently we just give a specified one
        """
        This function returns the effectiveness for counter flow fluids
        """
        epsilon=((1 - exp(-Ntu * (1 - Cr)))/(1 - Cr * exp(-Ntu * (1 - Cr))))
        return epsilon
    def areaFun(self):
        return self.Area
    def UFun(self):
        h_r=self.hFun()
        h_m=self.hFun()
        sigma=0.001
        k=100000 #pipe's thermal transfer coefficient
        U=1/(1/h_r+1/sigma/k+1/h_m)
        return U
    def hFun(self):
        # choose which correlation to be used according to parameters, such as Re,
        # Nu, Pr etc.
        #Red=rho
        #h=self.gnielinski(k,D,f,Red,Pr)
        h=100000
        return h
    def gnielinski(self,k,D,f,Red,Pr):
        return k/D*f/8*Pr*(Red-1000)/(1+12.7*(f/8)**0.5*(Pr**(2/3)-1))
    

if __name__=='__main__':
    kwds={
            'ref':'R134a',
            'Backend_r':'HEOS',
            'medium':'Water',
            'Backend_m':'HEOS',
            # inlet state of mediums
            'Pin_r':PropsSI('P','T',45+273.15,'Q',1,'R134a'),
            'Tin_r':70+273.15,
            'mdot_r':0.056,
            'Pin_m':100000,
            'Tin_m':20+273.15,
            'mdot_m':1,
            #geometry information
            'Area':28
 #air property is not know
          }
    hx=HXElementClass(**kwds)
    hx.calculate()
    print hx.Q
    print hx.Tout_r
    print hx.Area

    
 


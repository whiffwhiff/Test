# -*- coding: utf-8 -*-
"""
the model is used to simulate an ideal expansion equipment, so h_in, P_in, 
P_out, MF will be used as input parameters
Created on Sun Nov 25 17:37:06 2018

@author: whiff
"""
from __future__ import division
from CoolProp.CoolProp import PropsSI
import CoolProp as CP

class IdealExpansionEquipmentClass():

    def __init__(self,**kwargs):
        #Load up the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def update(self,**kwargs):
        #Update the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def calculate(self):
        self.hout_r=self.hin_r

        #AbstractState
        if hasattr(self,'Backend'): #check if backend is given
            AS = CP.AbstractState(self.Backend, self.ref)
        else: #otherwise, use the defualt backend
            AS = CP.AbstractState('HEOS', self.ref)
        AS.update(CP.HmassP_INPUTS, self.hout_r,self.Pout_r)
        self.Tout_r=AS.T()
        
if __name__=='__main__':
    kwds={'ref':'R134a',
          'Backend':'HEOS', #choose between: 'HEOS','TTSE&HEOS','BICUBIC&HEOS','REFPROP','SRK','PR'
          'Pin_r':PropsSI('P','T',45+273.15,'Q',1,'R134a'),
          'hin_r':PropsSI('H','T',40+273.15,'Q',0,'R134a'),
          'mdot':0.005,#SI unit kg/s
          'Pout_r':PropsSI('P','T',5+273.15,'Q',1,'R134a'),
          }
    expan=IdealExpansionEquipmentClass(**kwds)
    expan.calculate()
    print (expan.Tout_r)
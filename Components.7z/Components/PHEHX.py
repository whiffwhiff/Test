# -*- coding: utf-8 -*-
"""
Created on Tue Oct 16 21:14:59 2018

@author: whiff
"""

class PHEHXClass():
    def __init__(self,**kwargs):
        #Load up the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def update(self,**kwargs):
        #Update the parameters passed in
        # using the dictionary
        self.__dict__.update(kwargs)
    def calculate(self):
        pass
    
    '''
    input information:
        
    dimension
        height
        width
        depthMedium
        depthRef
        depthPlate
        circuitNo 
    m1
        name
        backend
        inlet state
        outletState
        MF
    m2
        name
        backend
        inlet state
        outletState
        MF
    
    logic statement
    epsilon-NTU
    heatTransferCorrelation
    pressureDropCorrelation
    
    
    '''

    

if __name__=='__main__':

    kwds={
            'ref':'R290',
            'Backend_r':'HEOS',
            'medium':'Water',
            'Backend_m':'HEOS',
            # inlet state of mediums
            'P_r_in':1500000,
            'T_r_in':70+273.15,
            'mdot_r':0.1,
            'P_m_in':100000,
            'T_m_in':20+273.15,
            'mdot_m':1  
 
          }
    thePHEHX=PHEHXClass()
    thePHEHX.calculate()
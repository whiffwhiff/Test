# -*- coding: utf-8 -*-
"""
simple refrigeration system model
Created on Sun Nov 25 18:00:44 2018

@author: whiff
"""

from __future__ import division
from CoolProp.CoolProp import PropsSI
import CoolProp as CP
from scipy.optimize import fsolve
from Compressor import CompressorClass as CompClass
from HX_simple import HXElementClass as HXClass
from IdealExpansionEquipment import IdealExpansionEquipmentClass as ExpClass

class cycleClass():
    def __init__(self,**kwargs):
        #Load up the parameters passed in
        # using the dictionary
        self.comp=CompClass()
        self.cond=HXClass()
        self.evap=HXClass()
        self.exp=ExpClass()
        
        self.__dict__.update(**kwargs['sysKwargs']) #comment the sentence, because it will
        #make program to store the informaiton repeatly and they are unncessary
        
        self.comp.__dict__.update(**kwargs['compKwargs'])
        self.cond.__dict__.update(**kwargs['condKwargs'])
        self.evap.__dict__.update(**kwargs['evapKwargs'])
        self.exp.__dict__.update(**kwargs['expKwargs'])
    def update(self,**kwargs):
        #Update the parameters passed in
        # using the dictionary
        self.__dict__.update(**kwargs['sysKwargs']) #comment the sentence, because it will
        #make program to store the informaiton repeatly and they are unncessary
        self.comp.__dict__.update(**kwargs['compKwargs'])
        self.cond.__dict__.update(**kwargs['condKwargs'])
        self.evap.__dict__.update(**kwargs['evapKwargs'])
        self.exp.__dict__.update(**kwargs['expKwargs'])
    
    def initialFun(self):
        """
        input: condMediumInletTemp, evapMediumInletTemp
        run this function to get initial guess values(Pc,Pe), which will be used as
        return:initial guess values as the input of cycleFun()
        """

        #AbstractState, To increase calculation speed,  table-based interpolation 
        # methods may be used.
        if hasattr(self,'Backend'): #check if backend is given
            AS = CP.AbstractState(self.Backend, self.Ref)
        else: #otherwise, use the defualt backend
            AS = CP.AbstractState('HEOS', self.ref)
        self.AS = AS

        # some information should input to get Tevap and Tcond
        evapMediumTemp=27+273.15
        evapDeltaTemp=-22  #Tr-Tm
        Tevap=evapMediumTemp + evapDeltaTemp
        condMediumTemp=35+273.15
        condDeltaTemp=10 #Tr-Tm
        Tcond=condMediumTemp + condDeltaTemp        
        SH=5 #K
        
        # PcompIn~=Pe,h=fun(PcompOut,SH=20F),PcompOut=Pc
        self.comp.Tin_r=Tevap+SH
        AS.update(CP.QT_INPUTS, 1.0, Tevap)
        self.comp.Pin_r=AS.p() # [Pa]
        AS.update(CP.PT_INPUTS, self.comp.Pin_r, self.comp.Tin_r)
        self.comp.hin_r=AS.hmass() # [Pa]
        AS.update(CP.QT_INPUTS, 1.0, Tcond)
        self.comp.Pout_r=AS.p() # [Pa]
        self.comp.calculate()
        
        #solve condenser model
        self.cond.Pin_r=self.comp.Pout_r
        self.cond.Tin_r=self.comp.Tout_r########
        self.cond.hin_r=self.comp.hout_r
        self.cond.mdot_r=self.comp.mdot_r
        self.cond.calculate()#currently air side parameters were not updated
        
        #solve expansion equipment
        self.exp.Pin_r=self.cond.Pout_r
        self.exp.Tin_r=self.cond.Tout_r
        self.exp.hin_r=self.cond.hout_r
        self.exp.Pout_r=self.comp.Pin_r #update expansion equpiment outlet 
        # pressure using compressor outlet pressure
        self.exp.mdot_r=self.cond.mdot_r
        self.exp.calculate()
        
        #solve evaporator model
        self.evap.Pin_r=self.exp.Pout_r
        self.evap.Tin_r=self.exp.Tout_r
        self.evap.hin_r=self.exp.hout_r
        self.evap.mdot_r=self.exp.mdot_r
        self.evap.calculate()#currently air side parameters were not updated

        x0=[]
        x0.append(self.comp.Pin_r)
        x0.append(self.comp.Pout_r)
        return x0
    
    def cycleFun(self,x):
        """
        artifical funcitions,independent variables were used firstly, now use:
        independent variables were: PcompDisch,PevapIn
        funcitions: Fun={PevapOut-PcompIn,hevapOut-hcompIn}
        
        comp--cond--exp--evap : sequentially call componentModel.calcualte()
        return residentials
        """
        #receive input parameters, they will be updated during NR solve process
        self.exp.Pout_r=x[0]        
        self.comp.Pout_r=x[1]
        print x[0]
        print x[1]
        
        
        #calculation sequentially, to be convinient P,h may be used as uniform port parameters
        #solve compressor model
        self.comp.calculate()
        
        #solve condenser model
        self.cond.Pin_r=self.comp.Pout_r
        self.cond.Tin_r=self.comp.Tout_r
        self.cond.hin_r=self.comp.hout_r
        self.cond.mdot_r=self.comp.mdot_r
        self.cond.calculate()#currently air side parameters were not updated
        
        #solve expansion equipment
        self.exp.Pin_r=self.cond.Pout_r
        self.exp.Tin_r=self.cond.Tout_r
        self.exp.hin_r=self.cond.hout_r
        self.exp.mdot_r=self.cond.mdot_r
        self.exp.calculate()
        
        #solve evaporator model
        self.evap.Pin_r=self.exp.Pout_r
        self.evap.Tin_r=self.exp.Tout_r
        self.evap.hin_r=self.exp.hout_r
        self.evap.mdot_r=self.exp.mdot_r
        self.evap.calculate()#currently air side parameters were not updated
        
        #now residual functions are availabe
        resid=[]
        resid.append(self.evap.Pout_r-self.comp.Pin_r)
        resid.append(self.evap.hout_r-self.comp.hin_r)
        
        #it seems necessary to update some parameters of components
        '''do it, if necessary
        make sure the port parameters got'''
        # will it be beneficial greatly if component models inherent coolprop model?
        
        return resid
        

    
    def calculate(self):
        """
        return=fsolve(cycleFun(),x0)
        """
        # Use the preconditioner to determine a reasonably good starting guess
        x0=self.initialFun()

        #Actually run the solver to get the solution
        x=fsolve(self.cycleFun,x0,full_output=True,xtol=1e-6)
        
        return x

    
if __name__=='__main__':
    sysKwargs={'ref':'R134a',
            'Backend_r':'HEOS'
            }
    compKwargs={
          'M':[217.3163128,5.094492028,-0.593170311,4.38E-02,-2.14E-02,1.04E-02,7.90E-05,-5.73E-05,1.79E-04,-8.08E-05],
          'P':[-561.3615705,-15.62601841,46.92506685,-0.217949552,0.435062616,-0.442400826,2.25E-04,2.37E-03,-3.32E-03,2.50E-03],
          'ref':'R134a',
          'Tin_r':280,
          'Pin_r':PropsSI('P','T',279,'Q',1,'R134a'),
          'Pout_r':PropsSI('P','T',315,'Q',1,'R134a'),
          'fp':0.15, #Fraction of electrical power lost as heat to ambient
          'Vdot_ratio': 1.0, #Displacement Scale factor
          'Backend':'HEOS' #choose between: 'HEOS','TTSE&HEOS','BICUBIC&HEOS','REFPROP','SRK','PR'
          }
    condKwargs={
            'ref':'R134a',
            'Backend_r':'HEOS',
            'medium':'Water',
            'Backend_m':'HEOS',
            # inlet state of mediums
            'Pin_r':1500000,
            'Tin_r':70+273.15,
            'mdot_r':0.1,
            'Pin_m':100000,
            'Tin_m':40+273.15,
            'mdot_m':1,
            #geometry information
            'Area':70
 
          }
    evapKwargs={
            'ref':'R134a',
            'Backend_r':'HEOS',
            'medium':'Water',
            'Backend_m':'HEOS',
            # inlet state of mediums
            'Pin_r':1500000,
            'Tin_r':0+273.15,
            'mdot_r':0.1,
            'Pin_m':100000,
            'Tin_m':20+273.15,
            'mdot_m':1, 
            #geometry information
            'Area':20
          }
            
    expKwargs={
            'ref':'R134a',
          'Pin_r':PropsSI('P','T',45+273.15,'Q',1,'R134a'),
          'hin_r':PropsSI('H','T',40+273.15,'Q',0,'R134a'),
          'mdot':0.005,#SI unit kg/s
          'Pout_r':PropsSI('P','T',5+273.15,'Q',1,'R134a'),
          'Backend':'HEOS' #choose between: 'HEOS','TTSE&HEOS','BICUBIC&HEOS','REFPROP','SRK','PR'
          }
    inputKwargs={'sysKwargs':sysKwargs,
            'compKwargs':compKwargs,
            'condKwargs':condKwargs,
            'evapKwargs':evapKwargs,
            'expKwargs':expKwargs
            }
    
    sys=cycleClass(**inputKwargs)
    sys.calculate()
    print
    print (sys.__dict__)
    print sys.evap.Q
    print sys.cond.Q
    print sys.comp.W
    print sys.comp.Pin_r
    print sys.comp.Pout_r
    
    
    
    